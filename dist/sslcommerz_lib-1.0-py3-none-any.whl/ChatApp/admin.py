from django.contrib import admin
from .models import chatMessages
# Register your models here.
admin.site.register(chatMessages)